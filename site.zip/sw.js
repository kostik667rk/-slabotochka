const CACHE = 'roscosmos-0039-v1';
const scope = new URL(self.registration.scope);
const core = [
  './index.html', './manifest.webmanifest', './icon-0035-192.png', './icon-0035-512.png', './apple-touch-icon.png', './apple-touch-icon-0035.png',
  './splash-0035-portrait.jpg', './logo-0035.png',
  './vendor/pdf.min.js', './vendor/pdf.worker.min.js',
  './vendor/pdf-lib.min.js', './vendor/fontkit.umd.min.js'
].map(path => new URL(path, scope).href);

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await cache.addAll(core.map(url => new Request(url, { cache: 'reload' })));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if ((name.startsWith('slabotochka-') || name.startsWith('roscosmos-')) && name !== CACHE) await caches.delete(name);
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  const appPage = url.origin === scope.origin &&
    (url.pathname === scope.pathname || url.pathname === new URL('./index.html', scope).pathname);
  if (!appPage && !core.includes(url.href)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const key = appPage ? core[0] : url.href;
    return await cache.match(key) || fetch(event.request);
  })());
});
